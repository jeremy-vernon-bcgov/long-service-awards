<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class UsersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
            'name' => 'jeremyvernon',
            'email' => 'jeremy.vernon@gov.bc.ca',
            'password' => '$2y$10$sYjKMm/zjRcbES7imiq7AezUJUh87yDDKciIv826sGeHKv1rBS.Di%',
            'role' => 'superadmin',
        ]);
        DB::table('users')->insert([
            'name' => 'apuns',
            'email' => 'amanda.punshon@gov.bc.ca',
            'password' => '$2y$10$ePcqxsCoKSHpUh/I6ArWbOD6lfHX64afpsojrBtEt2nFGoaDsMhSC',
            'role' => 'superadmin',
        ]);
    }
}
